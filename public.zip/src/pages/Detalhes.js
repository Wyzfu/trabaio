import { useParams } from 'react-router-dom';
import Detalhes from "./pages/Detalhes";
import DetalhesPage from './pages/DetalhesPage';


const Detalhes = () => {
  const { id } = useParams();

  return <DetalhesPage id={id} />;
};


export default Detalhes;


