import { useState, useEffect } from "react";
import CommentList from "../components/Comments/commentList";

function DetalhesPage() {
  const [comments, setComentarios] = useState([]);

  return (
    <div className="container">
          <div>
            <h2>Comentários:</h2>
            <CommentList filmeId={id} />
          </div>
    </div>);
}

export default DetalhesPage;
