const comentarios = [
    {
        id: 1,
        usuario: "Ana",
        texto: " Bom",
        filmeId: 96
    },
    {
        id: 2,
        usuario: "Paula",
        texto: "Ruim",
        filmeId: 14
    }
    
  ];
  
  export default comentarios;